﻿using ConsoleQuest.scene.item;

namespace ConsoleQuest.scene.factory
{
    /**
     * <summary>
	 * TownCommandSelectorFactoryクラスを生成するクラスです。
	 * </summary>
	 *
	 */
    public class TownCommandSelectorFactory : CommandSelectorFactory
    {

        /**
         * <summary>
		 * TownCommandSelectorFactoryクラスを返却します。
		 * </summary>
		 *
		 */
        public override CommandSelector CreateAction()
        {
            return new TownCommandSelector();
        }
    }
}
