﻿using ConsoleQuest.scene.item;

namespace ConsoleQuest.scene.factory
{
    /**
     * <summary>
	 * MoveCommandSelectorFactoryクラスを生成するクラスです。
	 * </summary>
	 * 
	 */
    public class MoveCommandSelectorFactory : CommandSelectorFactory
    {

        /**
         * <summary>
		 * MoveCommandSelectorFactoryクラスを返却します。
		 * </summary>
		 *
		 */
        public override CommandSelector CreateAction()
        {
            return new MoveCommandSelector();
        }
    }
}
