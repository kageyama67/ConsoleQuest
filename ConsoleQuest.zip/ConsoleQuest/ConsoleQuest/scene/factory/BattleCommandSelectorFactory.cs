﻿using ConsoleQuest.scene.item;

namespace ConsoleQuest.scene.factory
{
    /**
	 * <summary>
	 * BattleCommandSelectorクラスを生成するクラスです。
	 * </summary>
	 *
	 */
    public class BattleCommandSelectorFactory : CommandSelectorFactory
    {

        /**
         * <summary>
		 * BattleActionクラスを返却します。
		 * </summary>
		 * 
		 */
        public override CommandSelector CreateAction()
        {
            return new BattleCommandSelector();
        }
    }
}
