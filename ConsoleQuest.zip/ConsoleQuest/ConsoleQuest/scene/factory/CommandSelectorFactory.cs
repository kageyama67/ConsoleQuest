﻿using ConsoleQuest.scene.item;

namespace ConsoleQuest.scene.factory
{
	/**
	 * <summary>
	 * CommandSelectorクラスの生成を行う基底クラスです。
	 * </summary>
	 *
	 */
	public abstract class CommandSelectorFactory
	{
		/**
	     * <summary>
		 * 生成されたCommandSelectorクラスを返却します。
	     * </summary>
		 *
         * <returns>生成されたアクションクラス</returns>
		 */
		public CommandSelector Create()
		{
			CommandSelector action = CreateAction();
			return action;
		}

		/**
	     * <summary>
		 * CommandSelectorクラスの生成を行う抽象メソッドです。
	     * </summary>
		 *
         * <returns>生成されたアクションクラス</returns>
		 */
		public abstract CommandSelector CreateAction();
	}
}
