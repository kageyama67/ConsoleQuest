﻿using ConsoleQuest.entity;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.scene.controller;
using static ConsoleQuest.common.enumerated.BattleActionEnum;
using System;

namespace ConsoleQuest.scene.item
{
	/**
	 * <summary>
	 * BattleControllerクラスのビルダークラスです。
	 * </summary>
	 */
	public class ButtleControllerBuilder
	{
		public MonsterEntity monster { get; set; }
		public PlayerEntity player { get; set; }

		/**
		 * <summary>
		 * ビルダークラスのコンストラクタです。
		 * </summary>
		 *
		 * <param name="monster"></param>
		 * <param name="player"></param>
		 */
		public ButtleControllerBuilder(MonsterEntity monster, PlayerEntity player)
		{
			this.monster = monster;
			this.player = player;
			this.monster.action = None;
			this.player.action = None;
		}

		/**
		 * <summary>
		 * モンスターの行動を設定する。
		 * </summary>
		 *
		 * <param name="monsterAction"></param>
		 * <returns>自分自身を返す</returns>
		 */
		public ButtleControllerBuilder SetMonsterAction(BattleActionEnum monsterAction)
		{
			monster.action = monsterAction;
			return this;
		}

		/**
		 * <summary>
		 * プレイヤーの行動を設定する。
		 * </summary>
		 *
		 * <param name="playerAction"></param>
		 * <returns>自分自身を返す</returns>
		 */
		public ButtleControllerBuilder SetPlayerAction(BattleActionEnum playerAction)
		{
			player.action = playerAction;
			return this;
		}

		/**
		 * <summary>
		 * BattleControllerクラスを返却する。
		 * ビルダークラスに設定された情報をBattleControllerクラスに引き渡す。
		 * </summary>
		 *
		 * <returns>バトルコントローラを返却</returns>
		 */
		public BattleController Build()
		{
			if (monster.action == None || player.action == None)
            {
				throw new InvalidOperationException("Not Enough Setting of BattleController's Paramer.");
			}
			return new BattleController(this);
		}
	}
}
