﻿using System;
using ConsoleQuest.util;


namespace ConsoleQuest.scene.controller
{
	/**
	 * <summary>
	 * ショップシーン進行を制御するクラスのスーパークラスです。
	 * </summary>
	 *
	 */
	public abstract class ShopController
	{
		/**
		 * <summary>
		 * お店でのやりとりを進行します。
		 * </summary>
		 *
		 */
		public void Run()
		{
			Greeting();
			Operation();
		}

		/**
		 * <summary>
		 * あいさつ。
		 * </summary>
		 *
		 */
		protected abstract void Greeting();
		/**
		 * <summary>
		 * 店の対応。
		 * </summary>
		 *
		 */
		protected abstract void Operation();

		/**
		 * <summary>
		 * ありがとうございました。
		 * </summary>
		 *
		 */
		protected void Thanks()
		{
            Utility.ConsoleClear();
            Console.WriteLine("またのお越しをお待ちしております。");
            Utility.Sleep(800);
            Console.WriteLine("ありがとうございました。");
            Utility.Sleep(800);
        }
	}
}
