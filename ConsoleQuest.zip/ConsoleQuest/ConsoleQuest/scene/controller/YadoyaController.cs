﻿using System;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.util;
using static ConsoleQuest.common.enumerated.CommandEnum;
using static ConsoleQuest.common.Constants;
using ConsoleQuest.entity;

namespace ConsoleQuest.scene.controller
{
	/**
	 * 宿屋シーンを進行するクラスです。
	 *
	 */
	public class YadoyaController : ShopController
	{

		/**
		 * あいさつ。
		 *
		 */
		protected override void Greeting()
		{
            Utility.ConsoleClear();
            Console.WriteLine("宿屋へようこそ。");
			Console.WriteLine("");
		}
		/**
		 * 宿屋の対応。
		 *
		 */
		protected override void Operation()
		{
			while (true)
			{
				var player = Utility.GetPlayerInfo();
				Utility.Sleep(WaitTime);
                Console.WriteLine("一晩" + Yadoya.GetCommandValue2() + "ゴールドになりますが、お泊りなりますか?");
				Console.WriteLine("所持ゴールド：" + player.gold + "G");
				Console.WriteLine("");
				var command = CommandHandler.GetInputCommand(CommandTypeEnum.YesNo, null);
				switch (command)
				{
					case Yes:
						if (player.gold < int.Parse(Yadoya.GetCommandValue2()))
						{
                            Utility.ConsoleClear();
                            Console.WriteLine("残念ですが、お持ちのゴールドが不足しているようです。");
                            Utility.Sleep(WaitTime);
                            Console.WriteLine(player.name + "は宿屋を後にした。");
                            Utility.Sleep(WaitTime);
                            return;
						}
						Console.WriteLine("");
						Console.WriteLine("ありがとうございます。");
						Utility.Sleep(WaitTime);
						Console.WriteLine("それでは、ごゆっくり おやすみください。");
						Save(player);
						Utility.Sleep(WaitTime * 2);
                        Utility.ConsoleClear();
                        Console.WriteLine("おはようございます。");
                        Utility.Sleep(WaitTime);
                        Console.WriteLine("では いってらっしゃいませ。");
                        Utility.Sleep(WaitTime);
                        return;
					case No:
						Thanks();
						return;
				}
			}
		}
		/**
		 * <summary>
		 * セーブ
		 * </summary>
		 *
		 */
		private void Save(PlayerEntity player)
		{
			player.gold = player.gold - int.Parse(Yadoya.GetCommandValue2());
			player.hp = player.maxhp;
			player.mp = player.maxmp;
			JsonHandler.ToJson(JsoFilePathPlayer, player);
		}
	}
}
