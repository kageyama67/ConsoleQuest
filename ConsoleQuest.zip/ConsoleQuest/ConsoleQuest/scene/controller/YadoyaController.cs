﻿using System;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.common;
using ConsoleQuest.util;
using static ConsoleQuest.common.enumerated.CommandEnum;

namespace ConsoleQuest.scene.controller
{
	/**
	 * 宿屋シーンを進行するクラスです。
	 *
	 */
	public class YadoyaController : ShopController
	{

		/**
		 * あいさつ。
		 *
		 */
		protected override void Greeting()
		{
            Utility.ConsoleClear();
            Console.WriteLine("宿屋へようこそ。");
			Console.WriteLine("");
		}
		/**
		 * 宿屋の対応。
		 *
		 */
		protected override void Operation()
		{
			while (true)
			{
				var player = Utility.GetPlayerInfo();
				Utility.Sleep(800);
                Console.WriteLine("一晩" + CommandEnum.Yadoya.GetCommandValue2() + "ゴールドになりますが、お泊りなりますか?");
				Console.WriteLine("所持ゴールド：" + player.gold + "G");
				Console.WriteLine("");
				var command = CommandHandler.GetInputCommand(CommandTypeEnum.YesNo, null);
				switch (command)
				{
					case Yes:
						if (player.gold < int.Parse(CommandEnum.Yadoya.GetCommandValue2()))
						{
                            Utility.ConsoleClear();
                            Console.WriteLine("残念ですが、お持ちのゴールドが不足しているようです。");
                            Utility.Sleep(800);
                            Console.WriteLine(player.name + "は宿屋を後にした。");
                            Utility.Sleep(800);
                            return;
						}
						//Util.consoleClear();
						Console.WriteLine("ありがとうございます。");
						//Util.sleep(800);
						Console.WriteLine("それでは、ごゆっくり おやすみください。");
						player.gold = player.gold - int.Parse(CommandEnum.Yadoya.GetCommandValue2());
						player.hp = player.maxhp;
						player.mp = player.maxmp;
                        Utility.Sleep(2000);
                        Utility.ConsoleClear();
                        Console.WriteLine("おはようございます。");
                        Utility.Sleep(800);
                        Console.WriteLine("では いってらっしゃいませ。");
                        Utility.Sleep(800);
                        return;
					case No:
						Thanks();
						return;
				}
			}
		}
	}
}
