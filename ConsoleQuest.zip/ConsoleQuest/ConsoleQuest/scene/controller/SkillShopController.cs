﻿using System;
using ConsoleQuest.entity;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.common;
using ConsoleQuest.util;
using System.Collections.Generic;
using static ConsoleQuest.common.enumerated.CommandEnum;

namespace ConsoleQuest.scene.controller
{
	/**
	 * <summary>
	 * スキルショップシーンを進行するクラスです。
	 * </summary>
	 *
	 */
	public class SkillShopController : ShopController
	{
		/**
		 * <summary>
		 * あいさつ。
		 * </summary>
		 *
		 */
		protected override void Greeting()
		{
			Utility.ConsoleClear();
			Console.WriteLine("スキルショップへようこそ。");
			Console.WriteLine("");
		}
		/**
		 * <summary>
		 * スキルショップの対応。
		 * </summary>
		 *
		 */
		protected override void Operation()
		{
			while (true)
			{
				var player = Utility.GetPlayerInfo();
				Utility.Sleep(800);
				var skill = SelectSkill(player);
				if (skill == Exit)
				{
					Thanks();
					return;
				}
				else
				{
					Utility.ConsoleClear();
					Console.WriteLine(skill.GetCommandValue1() + "をお買い求めですね。");
					Utility.Sleep(800);
					Console.WriteLine(skill.GetCommandValue3() + "ゴールドになりますが、よろしいでしょうか?");
					Console.WriteLine("");
					var command = CommandHandler.GetInputCommand(CommandTypeEnum.YesNo, null);
					switch (command)
					{
						case Yes:
							if (player.gold < int.Parse(skill.GetCommandValue3()))
							{
								Utility.ConsoleClear();
								Console.WriteLine("残念ですが、お持ちのゴールドが不足しているようです。");
								Utility.Sleep(800);
								if (AskOtherOrder())
								{
									continue;
								}
								else
								{
									return;
								}
							}
							string skillKey = skill.GetCommandKey();
							var mySkills = new List<SkillEntity>();
							if (player.skills != null)
							{
								SkillEntity mySkill = player.skills.Find(e => e.skill.Equals(skill.GetCommandKey()));
								if (mySkill != null)
								{
									Utility.ConsoleClear();
									Console.WriteLine("そのスキルはすでにお持ちのようですね。");
									Utility.Sleep(800);
									if (AskOtherOrder())
									{
										continue;
									}
									else
									{
										return;
									}
								}
								player.skills.ForEach(e => mySkills.Add(e));
							}
							Utility.ConsoleClear();
							Console.WriteLine("ありがとうございます。");
							Utility.Sleep(800);
							Console.WriteLine(skill.GetCommandValue1() + "のスキル習得書をお渡します。");
							// 途中状況保存
							Save(skill, player, mySkills);
							Utility.Sleep(800);
							Console.WriteLine("");
							if (AskOtherOrder())
							{
								continue;
							}
							else
							{
								return;
							}
						case No:
							Utility.ConsoleClear();
							Console.WriteLine("おやめになるんですね。");
							Utility.Sleep(800);
							if (AskOtherOrder())
							{
								continue;
							}
							else
							{
								return;
							}
					}
				}
			}
		}

		/**
		 * <summary>
		 * 購入スキルの選択。
		 * </summary>
		 *
		 */
		private CommandEnum SelectSkill(PlayerEntity player)
		{
			while (true)
			{
				Console.WriteLine("とのスキルをお買い求めでしょうか。");
				Console.WriteLine("所持ゴールド：" + player.gold + "G");
				Console.WriteLine("");
				var skillCommand = CommandHandler.InputCommandForItem(CommandTypeEnum.Skill, Utility.GetExitList(), player.area);
				return skillCommand;
			}
		}

		/**
		 * <summary>
		 * 他にご用はありますか?
		 * </summary>
		 *
		 */
		private bool AskOtherOrder()
		{
			Console.WriteLine("他にご用はありますか?");
			Console.WriteLine("");
			var command = CommandHandler.GetInputCommand(CommandTypeEnum.YesNo, null);
			switch (command)
			{
				case Yes:
					Utility.ConsoleClear();
					return true;
				case No:
					Utility.ConsoleClear();
					Thanks();
					break;
			}
			return false;
		}

		/**
		 * <summary>
		 * 買い物途中状況セーブ
		 * </summary>
		 *
		 */
		private void Save(CommandEnum skill, PlayerEntity player, List<SkillEntity> mySkills)
		{
			var boughtSkill = new SkillEntity();
			boughtSkill.skill = skill.GetCommandKey();
			mySkills.Add(boughtSkill);
			player.gold = player.gold - int.Parse(skill.GetCommandValue3());
			player.skills = mySkills;
			JsonHandler.ToJson(Constants.JsoFilePathPlayer, player);
		}
	}
}
