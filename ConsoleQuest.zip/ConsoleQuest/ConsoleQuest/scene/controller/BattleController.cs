﻿using System;
using System.Collections.Generic;
using ConsoleQuest.scene.item;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.entity;
using ConsoleQuest.util;
using static ConsoleQuest.common.enumerated.BattleActionEnum;
using static ConsoleQuest.common.enumerated.BattleResultEnum;
using static ConsoleQuest.common.Constants;

namespace ConsoleQuest.scene.controller
{
	/**
     * <summary>
     * 戦闘シーンを進行するクラスです。
     * </summary>
     */
	public class BattleController
	{
		private MonsterEntity monster;
		private PlayerEntity player;
		private List<LevelEntity> levelList;

		private static string[] MessageConnecter = {"は ", "に "};
		private static string[] MessageDamageTo = {"ポイントのダメージを受けた。", "ポイントのダメージを与えた。"};
		private static string[] MessageSmashDamageTo = {"の会心の一撃!! ", "の痛恨の一撃!! "};
		private static string[] MessageMissDamageTo = {"はダメージを受けない。", "にダメージを与えられない。"};

		/**
	     * <summary>
		 * コンストラクタ。
	     * </summary>
		 *
         * <param name="builder"></param>
		 */
		public BattleController(ButtleControllerBuilder builder)
		{
			var levelJson = JsonHandler.FromJson<LevelListEntity>(JsonFilePathLevel);
			levelList = levelJson.levels.FindAll(e => 1 == 1);
			monster = builder.monster;
			player = builder.player;
		}

		/**
	     * <summary>
		 * 選択されたコマンドを元に戦闘アクションを進行します。
	     * </summary>
		 *
		 * <returns>戦闘の行動結果を返却</returns>
		 */
		public BattleResultEnum Run()
		{
			// モンスター及びプレイヤー情報をリストに格納
			var activeList = new List<StatusEntity>();
			activeList.Add(monster);
			activeList.Add(player);

			// バトル参加キャラ数
			// n:nの戦闘に拡張したい
			int battleCharaCount = 2;

			// スピード(sp)に応じてリスト内の順序（先攻/後攻キャラクター）を変更する
			activeList.Sort((x, y) => - AjustNumber(x.sp).CompareTo(AjustNumber(y.sp)));

			var listBdo = new List<BattleDO>();
			for (int phase = 0; phase < battleCharaCount; phase++)
			{
				for (int order = 0; order < battleCharaCount; order++)
				{
					// phase:0 <攻撃、守備パラメータの設定>
					//   order:0 [1周目] 先攻キャラクターの攻撃、守備パラメータを設定
					//   order:1 [2周目] 後攻キャラクターの攻撃、守備パラメータを設定
					// phase:1  1周目で設定したパラメータに応じて、キャラクター間の攻防を行う
					//   order:0 [3周目] 先攻者のアクションを実施 (例：先攻キャラクターから後攻キャラクターに攻撃)
					//   order:1 [4周目] 後攻者のアクションを実施 (例：後攻キャラクターから先攻キャラクターにスキル攻撃)
					if (phase == 0 && order == 0)
					{
						// [1周目] 攻撃/守備パラメータの初期化
						listBdo = InitBattleDO(battleCharaCount);
					}
					if (phase == 0)
					{
						// [1, 2 周目] 攻撃/守備パラメータの設定
						switch (activeList[order].action)
						{
							case NormalAttack:
								listBdo[order].attack = AjustNumber(activeList[order].ap);
								break;
							case SmashAttack:
								listBdo[order].protectBreakAttack = AjustNumber(activeList[order].ap);
								break;
							case Guard:
								listBdo[order].guard = AjustNumber(activeList[order].pp) * Guard.GetBattleActionValue();
								break;
							case Mera:
								listBdo[order].protectBreakAttack = AjustNumber(Mera.GetBattleActionValue());
								break;
							case Merami:
								listBdo[order].protectBreakAttack = AjustNumber(Merami.GetBattleActionValue());
								break;
							default:
								//処理なし
								break;
						}
						listBdo[order].protect = AjustNumber(activeList[order].pp);

					}
					else
					{
						// [3, 4 周目] キャラクターのアクション
						int attacker = order;
						int receiver = (attacker == 0 ? 1 : 0);
						switch (activeList[attacker].action)
						{
							case NormalAttack:
								DoAction(activeList[attacker], activeList[receiver], listBdo[attacker], listBdo[receiver], MpZero, NormalAttack.GetBattleActionWord1());
								break;
							case SmashAttack:
								DoAction(activeList[attacker], activeList[receiver], listBdo[attacker], listBdo[receiver], MpZero, MessageSmashDamageTo[activeList[attacker].enemy]);
								break;
							case Guard:
								Console.Write(activeList[attacker].name + Guard.GetBattleActionWord1());
								Console.Write("");
								Utility.Sleep(WaitTime);
								break;
							case Mera:
								DoAction(activeList[attacker], activeList[receiver], listBdo[attacker], listBdo[receiver], Mera.GetBattleActionMp(), Mera.GetBattleActionWord1());
								break;
							case Merami:
								DoAction(activeList[attacker], activeList[receiver], listBdo[attacker], listBdo[receiver], Merami.GetBattleActionMp(), Merami.GetBattleActionWord1());
								break;
							case Hoimi:
								Heel(activeList[attacker], AjustNumber(Hoimi.GetBattleActionValue()), Hoimi.GetBattleActionMp(), Hoimi.GetBattleActionWord1(), Hoimi.GetBattleActionWord2());
								break;
							case Behoimi:
								Heel(activeList[attacker], AjustNumber(Behoimi.GetBattleActionValue()), Behoimi.GetBattleActionMp(), Behoimi.GetBattleActionWord1(), Behoimi.GetBattleActionWord2());
								break;
							case MonsterEscape:
								// TODO モンスターが「逃げる」ロジック未実装
								break;
							case Kialy:
								// TODO キアリー未実装(毒ステータス含め)
								break;
							case None:
								// 実装なし。
								break;
						}
						// TODO 毒ダメージ実装
						// 結果判定
						switch (JudgeBattleResult(activeList[receiver]))
						{
							case BattleResultEnum.Rose:
                                Rose();
								return BattleResultEnum.Rose;
							case BattleResultEnum.Win:
                                Win();
                                LevelUp();
								return BattleResultEnum.Win;
							default:
								break;
						}
					}
				}
			}
			return Continue;
		}
		/**
	     * <summary>
		 * 攻撃処理
	     * </summary>
		 *
		 * <param name="attacker">攻撃者の情報を保持するクラス</param>
		 * <param name="receiver">被攻撃者の情報を保持するクラス</param>
		 * <param name="abdo">攻撃者バトルDO</param>
		 * <param name="rbdo">被攻撃者バトルDO</param>
		 * <param name="skillMp">スキル消費MP</param>
		 * <param name="dispWord">攻撃時の表示メッセージ</param>
		 */
		private void DoAction(StatusEntity attacker, StatusEntity receiver, BattleDO abdo, BattleDO rbdo, int skillMp, string dispWord)
		{
			// 初期化
			int attack = abdo.attack;
			int protect = rbdo.protect;

			// 守備力無視攻撃ポイントが0以外の場合、攻撃ポイントに設定
			if (abdo.protectBreakAttack != 0)
			{
				attack = abdo.protectBreakAttack;
				protect = 0;
			}
			// guard（防御選択時）が0以外の場合、守備ポイントに設定
			if (rbdo.guard != 0)
            {
				protect = rbdo.guard;
			}

			// 「攻撃ポイント－守備ポイント」から、receiverに与えるダメージを計算 （0以下の場合は0）
			attack = (attack - protect) <= 0 ? 0 : (attack - protect);
			Console.WriteLine(attacker.name + dispWord);
			Utility.Sleep(WaitTime);
			if (attack == 0)
			{
				Console.Write("ミス!!  ");
				Utility.Sleep(WaitTime);
				Console.Write("{0}{1}\n", receiver.name, MessageMissDamageTo[receiver.enemy]);
				Console.WriteLine("");
				Utility.Sleep(WaitTime);
				return;
			}
			Console.WriteLine(receiver.name + MessageConnecter[receiver.enemy] +
					attack + MessageDamageTo[receiver.enemy]);

			Console.WriteLine("");
			Utility.Sleep(WaitTime);
			receiver.hp = ((receiver.hp - attack) < 0 ? 0 : (receiver.hp - attack));
			attacker.mp = (attacker.mp - skillMp);
		}

		/**
	     * <summary>
		 * 回復処理
	     * </summary>
		 *
		 * <param name="heeler">回復者の情報を保持するクラス</param>
		 * <param name="value">回復ポイント</param>
		 * <param name="skillMp">スキル消費MP</param>
		 * <param name="dispWord1">回復時の表示メッセージ1</param>
		 * <param name="dispWord2">回復時の表示メッセージ2</param>
		 */
		private void Heel(StatusEntity heeler, int value, int skillMp, string dispWord1, string dispWord2)
		{
			Console.WriteLine(heeler.name + dispWord1);
			Utility.Sleep(WaitTime);
			Console.WriteLine(heeler.name + dispWord2);
			Utility.Sleep(WaitTime);
			Console.Write("");
			if (heeler.maxhp < (heeler.hp + value))
			{
				heeler.hp = heeler.maxhp;
			}
			else
			{
				heeler.hp =heeler.hp + value;
			}
			heeler.mp = heeler.mp - skillMp;
		}
		/**
	     * <summary>
		 * 敗北処理
	     * </summary>
		 *
		 */
		private void Rose()
		{
			Utility.Sleep(WaitTime);
			Console.Write("{0}は戦いに敗れた。\n", player.name);
			Utility.Sleep(WaitTime * 2);
			player.hp = player.maxhp;
			player.mp = player.maxmp;
			player.gold = player.gold / 2;
		}
		/**
	     * <summary>
		 * 勝利処理
	     * </summary>
		 *
		 */
		private void Win()
		{
			Utility.Sleep(WaitTime);
			Console.Write("{0}は{1}を倒した!! \n", player.name, monster.name);
			Console.Write("  {0}ゴールド {1}ポイントの経験値を手に入れた。\n", monster.gold, monster.exp);
			Utility.Sleep(WaitTime);
			player.gold = player.gold + monster.gold;
			player.exp = player.exp + monster.exp;
			Console.Write("  所持ゴールド　：　{0} 　経験値　：　{1}\n", player.gold, player.exp);
		}
		/**
	     * <summary>
		 * 経験値が規定値に達していた場合、レベルアップ
	     * </summary>
		 *
		 */
		private void LevelUp()
		{
			// リストをレベル順にソート
			levelList.Sort((x, y) => x.level.CompareTo(y.level));
			foreach (var level in levelList)
			{
				if (level.level <= player.level)
					continue;
				if (level.exp <= player.exp)
				{
					Utility.Sleep(WaitTime);
					Console.WriteLine("");
					Console.Write("{0}は レベル{1} にあがった!! \n", player.name, level.level);
					Console.Write("");
					Utility.Sleep(WaitTime);
					Console.Write("  最大HP＋{0}\t",
							level.maxhp - player.maxhp < 0 ? 0 : level.maxhp - player.maxhp);
					Console.Write("  最大MP＋{0}\n",
							level.maxmp - player.maxmp < 0 ? 0 : level.maxmp - player.maxmp);
					Console.Write("  攻撃力＋{0}\t",
							level.ap - player.ap < 0 ? 0 : level.ap - player.ap);
					Console.Write("  守備力＋{0}\t",
							level.pp - player.pp < 0 ? 0 : level.pp - player.pp);
					Console.Write("  スピード＋{0}\n",
							level.sp - player.sp < 0 ? 0 : level.sp - player.sp);
					Utility.PressAnyKey();
					// パラメータセット
					player.level = level.level;
					player.maxhp = level.maxhp;
					player.maxmp = level.maxmp;
					player.ap = level.ap;
					player.pp = level.pp;
					player.sp = level.sp;

				}
				else
				{
					break;
				}
			}
		}

		/**
	     * <summary>
		 * 戦闘結果判定
	     * </summary>
		 *
		 * <param name="receiver">被攻撃者の情報を保持するクラス</param>
		 * <returns>戦闘結果</returns>
		 */
		private BattleResultEnum JudgeBattleResult(StatusEntity receiver)
		{
			if (0 < receiver.hp)
				return Continue;
			if (receiver.enemy == 0)
				return BattleResultEnum.Rose;
			return BattleResultEnum.Win;
		}
		/**
	     * <summary>
		 * 数値調整
		 *
		 * n-a ～ n+a の間のランダム値
		 * 対象数値:n
		 * 対象数値にAJUST_PERCENTAGEをかけた数値:a
		 *  例： n=100, a=20の場合：80～120までの間のランダム値
	     * </summary>
		 *
		 * <param name="number">調整したい数値</param>
		 * <returns>調整後の数値</returns>
		 */
		private int AjustNumber(int number)
		{
			int n = (int)(number * BattleAjustPercentage);
			var rand = new Random();
			return number - n + (rand.Next((2 * n) + 1));
		}

		/**
	     * <summary>
		 * BattleDOの初期化
	     * </summary>
		 *
		 * <param name="cnt">初期化したいバトルDOの数</param>
		 * <returns>初期化後のDO</returns>
		 */
		private List<BattleDO> InitBattleDO(int cnt)
		{
			var lbdo = new List<BattleDO>();
			for (int i = 0; i < cnt ; i++)
            {
				var bdo = new BattleDO();
				bdo.attack = 0;
				bdo.protectBreakAttack = 0;
				bdo.protect = 0;
				bdo.guard = 0;
				lbdo.Add(bdo);
			}
			return lbdo;
		}
	}
}
