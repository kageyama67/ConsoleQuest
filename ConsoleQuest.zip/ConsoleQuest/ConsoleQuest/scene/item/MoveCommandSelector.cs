﻿using System;
using System.Collections.Generic;
using ConsoleQuest.util;
using ConsoleQuest.entity;
using ConsoleQuest.common;
using ConsoleQuest.common.enumerated;
using static ConsoleQuest.common.enumerated.CommandEnum;

namespace ConsoleQuest.scene.item
{
	/**
	 * <summary>
	 * 移動時における行動を選択するクラスです。
	 * </summary>
	 *
	 */
	public class MoveCommandSelector : CommandSelector
	{

		/**
		 * <summary>
		 * プレイヤーインスタンス。
		 * </summary>
		 */
		private PlayerEntity player = null;

		/**
		 * <summary>
		 * コンストラクタ。
		 * </summary>
		*/
		public MoveCommandSelector()
		{

			player = Utility.GetPlayerInfo();
        }

		/**
		 * <summary>
		 * 移動先の選択
		 * </summary>
		*/
		public void Start()
		{
			var ommitList = new List<string>();
			ommitList.Add(player.area);
			Utility.ConsoleClear();
			var area = CommandHandler.GetOmittedCommand(CommandTypeEnum.Area, ommitList, null);
			if (area == Exit)
            {
				return;
			}
			player.area = area.GetCommandKey();
			Utility.ConsoleClear();
			Console.WriteLine("{0}エリアに移動した。", area.GetCommandValue1());
			Utility.Sleep(800);
			JsonHandler.ToJson(Constants.JsoFilePathPlayer, player);
		}
	}
}
