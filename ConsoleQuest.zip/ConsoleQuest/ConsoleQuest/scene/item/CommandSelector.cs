namespace ConsoleQuest.scene.item
{
	/**
	 * アクションコマンドを実行する共通インターフェースです。
	 *
	 */
	public interface CommandSelector
	{
		/**
		 * <summary>
		 * アクションコマンドの実行を定義する抽象メソッドです。
		 * </summary>
		 *
		 */
		public abstract void Start();
	}
}


