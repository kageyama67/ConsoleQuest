﻿using System;
using System.Collections.Generic;
using ConsoleQuest.util;
using ConsoleQuest.entity;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.scene.controller;
using static ConsoleQuest.common.enumerated.CommandEnum;
using static ConsoleQuest.common.Constants;

namespace ConsoleQuest.scene.item
{
	/**
	 * <summary>
	 * 街シーンにおける行動を決定するクラスです。
	 * </summary>
	 *
	 */
	public class TownCommandSelector : CommandSelector
	{

		/**
		 * <summary>
		 * プレイヤーインスタンス。
		 * </summary>
		 */
		private PlayerEntity player = null;

		/**
		 * <summary>
		 * エリア情報。
		 * </summary>
		 */
		private CommandEnum area;

		/**
		 * <summary>
		 * コンストラクタ。
		 * </summary>
		*/
		public TownCommandSelector()
		{

			player = Utility.GetPlayerInfo();
			area = CommandHandler.GetCommandByKey(CommandTypeEnum.Area, player.area);
            Utility.ConsoleClear();
            Console.WriteLine("{0}の街についた。", area.GetCommandValue1());
            Utility.Sleep(WaitTime);
            Utility.ConsoleClear();
        }

		/**
		 * <summary>
		 * 街の移動先の選択
		 * </summary>
		*/
		public void Start()
		{
			while (true)
			{
				Console.WriteLine("{0}の街", area.GetCommandValue1());
				Console.WriteLine("");

				var addList = new List<string>();
				addList.Add(Param.GetCommandKey());
				var command = CommandHandler.GetInputCommand(CommandTypeEnum.Town, Utility.GetExitParamList());
				ShopController shop = null;
				switch (command)
				{
					case SkillShop:
						shop = new SkillShopController();
						break;
					case Yadoya:
						shop = new YadoyaController();
						break;
					case Param:
						Utility.DispParamInfo();
						break;
					case Exit:
						Utility.ConsoleClear();
						Console.WriteLine("{0}は{1}の街をあとにした。", player.name, area.GetCommandValue1());
						Utility.Sleep(WaitTime);
						return;
				}
				if (shop == null)
                {
					Utility.ConsoleClear();
					continue;
                }
				shop.Run();
				//player = Utility.GetPlayerInfo();
				//JsonHandler.ToJson(JsoFilePathPlayer, player);
				Utility.ConsoleClear();
			}
		}
	}
}
