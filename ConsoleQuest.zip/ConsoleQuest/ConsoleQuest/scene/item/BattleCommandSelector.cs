﻿using System;
using System.Collections.Generic;
using ConsoleQuest.entity;
using ConsoleQuest.strategy;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.common;
using ConsoleQuest.util;
using ConsoleQuest.scene.controller;
using static ConsoleQuest.common.enumerated.BattleResultEnum;
using static ConsoleQuest.common.enumerated.CommandEnum;
using static ConsoleQuest.common.Constants;

namespace ConsoleQuest.scene.item
{
    /**
	 * <summary>
	 * 戦闘シーンにおける行動を選択するクラスです。
	 * </summary>
	 *
	 */
    public class BattleCommandSelector : CommandSelector
    {

        /**
		 * モンスター関連のインスタンス。
		 */
        private List<MonsterEntity> monsterList;
        private MonsterEntity monster;
        private IStrategy strategy;

        /**
		 * プレイヤーインスタンス。
		 */
        private PlayerEntity player = null;

        /**
    	 * <summary>
		 * コンストラクタ。
    	 * </summary>
		 *
		 */
        public BattleCommandSelector()
        {
            // プレイヤー
            player = Utility.GetPlayerInfo();

            // モンスター設定
            var monsterJson = JsonHandler.FromJson<MonsterListEntity>(JsonFilePathMonster);
            monsterList = monsterJson.monsters.FindAll(e => e.area.Contains(player.area));
		}

        /**
    	 * <summary>
		 * 戦闘アクションコマンド選択
    	 * </summary>
		 *
		 */
        public void Start()
        {
            if (monsterList.Count == 0)
            {
                Console.WriteLine("周辺にモンスターはいないようです。");
                Utility.Sleep(WaitTime);
                return;
            }
            
            InitBattle();
            BattleController controller;
            // 初期値Continue
            BattleResultEnum result = Continue;
            while (true)
            {
                DispInfo();
                var addList = new List<string>();
                addList.Add(Param.GetCommandKey());
                var command = CommandHandler.GetInputCommand(CommandTypeEnum.Battle, Utility.GetExitParamList());
                var rand = new Random();

                switch (command)
                {
                    case Attack:
                        Utility.ConsoleClear();
                        controller = new ButtleControllerBuilder(monster, player)
                            .SetMonsterAction(strategy.SelectAction(monster, player))
                            .SetPlayerAction(
                                rand.Next(BattleActionEnum.SmashAttack.GetBattleActionValue()) == 1 ?
                                BattleActionEnum.SmashAttack :
                                BattleActionEnum.NormalAttack)
                            .Build();
                        result = controller.Run();
                        break;
                    case Skill:
                        Utility.ConsoleClear();
                        Console.WriteLine("スキルリスト");
                        var skillList = new List<string>();
                        if (player.skills == null || player.skills.Count == 0)
                        {
                            Console.WriteLine("スキルがありません。");
                            Utility.Sleep(WaitTime);
                            result = Continue;
                            break;
                        }
                        foreach (var skill in player.skills)
                        {
                            skillList.Add(skill.skill);
                        }
                        while (true)
                        {
                            result = SelectSkill(skillList);
                            break;
                        }
                        break;
				    case Guard:
                        Utility.ConsoleClear();
                        controller = new ButtleControllerBuilder(monster, player)
                            .SetMonsterAction(strategy.SelectAction(monster, player))
                            .SetPlayerAction(BattleActionEnum.Guard)
                            .Build();
                        result = controller.Run();
                        break;
                    case Param:
                        Utility.DispParamInfo();
                        break;
                    case Exit:
                        Utility.ConsoleClear();
                        Console.Write("{0}は逃げ出した。\n", player.name);
                        Utility.Sleep(WaitTime);
                        return;
                }

                switch (result)
                {
                    case Win:
                    case Rose:
                        JsonHandler.ToJson(JsoFilePathPlayer, player);
                        return;
                    case MosterEscape:
                    // 未実装
                    case Continue:
                        break;
                }
                Utility.ConsoleClear();
			}
		}

        /**
    	 * <summary>
		 * バトルの初期化
    	 * </summary>
		 *
		 */
        private void InitBattle()
        {
            // 出現モンスター決定
            var rand = new Random();
            monster = monsterList[rand.Next(monsterList.Count - 1)];

            // モンスター戦略設定
            IStrategy tmpStrategy;

            try
            {
                Type StratetyType = Type.GetType(monster.strategy);
                tmpStrategy
                  = (IStrategy)Activator.CreateInstance(StratetyType);
            }
            catch
            {
                // なんらかのエラーが発生した場合、NormalStrategyをセット。
                tmpStrategy = new NormalStrategy();
            }
            strategy = tmpStrategy;

            Console.WriteLine(tmpStrategy.SelectAction(monster, player));

            Utility.ConsoleClear();
            Console.WriteLine("{0}が現れた！", monster.name);
            Console.WriteLine("");
            Utility.Sleep(WaitTime);

        }

        /**
    	 * <summary>
		 * スキルコマンド選択処理
    	 * </summary>
		 *
         * <param name="skillList">選択可能なスキルリスト</param>
         * <returns>選択されたスキル</returns>
		 */
        private BattleResultEnum SelectSkill(List<string> skillList)
        {
            BattleActionEnum skill = BattleActionEnum.Cancel;
            Console.WriteLine("");
            var skillCommand = CommandHandler.GetFilterdCommand(CommandTypeEnum.Skill, skillList, Utility.GetExitList());
            switch (skillCommand)
            {
                case Mera:
                    skill = CheckAndsetSkill(BattleActionEnum.Mera);
                    break;
                case Merami:
                    skill = CheckAndsetSkill(BattleActionEnum.Merami);
                    break;
                case Hoimi:
                    skill = CheckAndsetSkill(BattleActionEnum.Hoimi);
                    break;
                case Behoimi:
                    skill = CheckAndsetSkill(BattleActionEnum.Behoimi);
                    break;
                case Kialy:
                    skill = CheckAndsetSkill(BattleActionEnum.Kialy);
                    break;
                case Exit:
                    Utility.Sleep(300);
                    return Continue;
            }
            Utility.ConsoleClear();
            BattleController controller = new ButtleControllerBuilder(monster, player)
                    .SetMonsterAction(strategy.SelectAction(monster, player))
                    .SetPlayerAction(skill)
                    .Build();
            return controller.Run();
        }

        /**
    	 * <summary>
         * 消費MPのチェック
    	 * </summary>
         */
        private BattleActionEnum CheckAndsetSkill(BattleActionEnum skill)
        {
            if (player.mp < skill.GetBattleActionMp())
            {
                Console.WriteLine("MPが足りない。");
                Console.WriteLine("");
                return BattleActionEnum.Cancel;
            }
            return skill;
        }

        /**
    	 * <summary>
         * 戦闘者情報の印字
    	 * </summary>
         */
        private void DispInfo()
        {
            Console.WriteLine(player.name + "  HP:" + player.hp + " MP:" + player.mp);
            Console.WriteLine(monster.name + "  HP:" + monster.hp + " MP:" + monster.mp);
            Console.WriteLine("");
        }
	}
}