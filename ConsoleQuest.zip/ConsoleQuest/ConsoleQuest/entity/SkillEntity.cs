﻿namespace ConsoleQuest.entity
{
	public class SkillEntity
	{
		public string skill { get; set; }
	}
}
