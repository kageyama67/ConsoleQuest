﻿
namespace ConsoleQuest.entity
{
	public class MonsterEntity : StatusEntity
	{
		public string strategy { get; set; }
	}
}
