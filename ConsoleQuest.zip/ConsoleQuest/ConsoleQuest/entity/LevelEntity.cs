﻿namespace ConsoleQuest.entity
{
	public class LevelEntity
	{
		public int level { get; set; }
		public int maxhp { get; set; }
		public int maxmp { get; set; }
		public int ap { get; set; }
		public int pp { get; set; }
		public int sp { get; set; }
		public int exp { get; set; }
	}
}
