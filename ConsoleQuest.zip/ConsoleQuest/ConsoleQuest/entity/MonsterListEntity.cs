﻿using System.Collections.Generic;

namespace ConsoleQuest.entity
{
	public class MonsterListEntity
	{
		public virtual List<MonsterEntity> monsters  { get; set; }
	}
}
