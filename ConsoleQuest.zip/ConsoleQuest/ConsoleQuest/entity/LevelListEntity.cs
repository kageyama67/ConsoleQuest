﻿using System.Collections.Generic;

namespace ConsoleQuest.entity
{
	public class LevelListEntity
	{
		public List<LevelEntity> levels { get; set; }
	}
}
