﻿/*

コンソールクエスト（勉強用）

＜環境について＞

・プロジェクト-Nugetパッケージ管理の参照タブからNlogを検索してインストール
・Cドライブ直下にtempフォルダを作成し、本プロジェクト[zz]配下のConsoleQuestフォルダをコピーペースト。

＜用語＞

・アリアハンとかレーベって？：ドラクエ３に出てくる街の名前。
・やどやって？：体を休める為のホテル。
・メラ、メラミって？：火の玉で敵を攻撃する呪文です。メラミのが強力。
・ホイミ、ベホイミって？：ダメージを回復する呪文です。ベホイミの方が強力。

＜遊び方＞ 
※下にいくほど難易度が高い

・新しいモンスターを作ってみる
・新しいスキルを作ってみる
・新しい街を作ってみる
・洞窟シーンを作ってみる
・道具を使えるようにしてみる。まずは薬草から。
・武器を装備できるようにしてみる。
・モンスターが複数登場するようにしてみる
・主人公を含め仲間を３人にしてみる


＜使われているデザインパターン＞

=========================================================================
[1] singletonパターン
=========================================================================
LogHandler.cs
    newが一度だけ実行される仕組みをもったクラス。メモリの消費を抑えます。


=========================================================================
[2] TemplateMethodパターン
=========================================================================
ShopController.cs（抽象クラス）
┗ SkillShopController.cs    （具象クラス）
┗ YadoyaController.cs       （具象クラス）

    親クラスが持つ抽象メソッドを、その子クラスが個別の実装を行する。
    クライアントは具象クラスをnewして抽象クラスの型に入れて使用。
    クライアント：TownAction.cs


=========================================================================
[3] FactoyMethodパターン
=========================================================================
ActionFactory.cs（抽象クラス）
┗ BattleActionFactory.cs （具象クラス）
    BattleAction.cs　を生成して返却
┗ TownActionFactory.cs （具象クラス）
    TownAction.cs　を生成して返却
┗ MoveActionFactory.cs （具象クラス）
    MoveAction.cs　を生成して返却

Action.cs（インターフェース）
┗ BattleAction.cs（継承）
┗ MoveAction.cs（継承）
┗ TownAction.cs（継承）

　同型を持つクラスを同類のFactoryクラスが生成してクライアントに返却する。
  TemplateMethodパターンより抽象度が高く疎結合になる。


=========================================================================
[4] Builderパターン
=========================================================================
BattleController.cs
┗ ButtleControllerBuilder.cs

    あるクラスを生成する為のクラスパターン。
    例えば、メンバー変数を多くもちをれをクライアントクラスから設定しようするような
    クラスを安全に生成させる意図で使用される


=========================================================================
[5] Strategyパターン
=========================================================================
IStrategy.cs
┗ NormalStrategy.cs
┗ SmashAttackAndHealStrategy.cs
┗ SmashAttackStrategy.cs
    戦略によって中身のクラスを切替て異なるふるまいをさせたい時にパターン
    ここでは、モンスターによって異なる行動パターンを各ストラテジークラスで実装している



＜クラス一覧＞
 [] 内数値は対応するデザインパターン

[root]
│
│  readme.txt                              このファイル
│  Program.cs                              エントリポイント(フィールド行動を選択するクラス)
│
├─common                                   
│  │  Constants.cs                         定数クラス
│  │  Messages.cs                          ログメッセージ定数クラス
│  │
│  └─enumerated                           
│          CommandEnum.cs                  行動コマンドを規定するEnumクラス
│          CommandTypeEnum.cs              コマンド種別を規定するEnumクラス（このゲームの肝★）
│          BattleActionEnum.cs             戦闘行動を規定するEnumクラス
│          BattleResultEnum.cs             戦闘結果を規定するEnumクラス
│
├─do                                       
│      BattleDO.cs                         戦闘情報を格納するDOクラス
│
├─entity                                   
│      LevelEntity.cs                      レベル情報を格納するEntityクラス
│      LevelListEntity.cs                  レベル情報のリストを格納するEntityクラス
│      MonsterEntity.cs                    モンスター固有情報を格納するEntityクラス
│      MonsterListEntity.cs                モンスター情報のリストを格納するEntityクラス
│      PlayerEntity.cs                     プレイヤー固有情報を格納するEntityクラス
│      SkillEntity.cs                      スキル情報を格納するEntityクラス
│      StatusEntity.cs                     ステータス情報を格納するEntityクラス
│
├─scene                                    各アクションのロジック群
│  ├─builder                              
│  │      ButtleControllerBuilder.cs       [4] BattleControllerのビルダークラス
│  │                                       
│  ├─controller                           
│  │      BattleController.cs              [4] 戦闘シーンを進行するクラス
│  │      ShopController.cs                [2] ショップシーンを進行する為の基底クラス
│  │      SkillShopController.cs           [2] スキルショップシーンを進行する具象クラス
│  │      YadoyaController.cs              [2] 宿屋シーンを進行する具象クラス
│  │                                       
│  ├─factory                              
│  │      CommandSelectorFactory.cs        [3] CommandSelector型のクラスを生成する基底ファクトリークラス
│  │      BattleCommandSelectorFactory.cs  [3] 戦闘時のコマンドセレクタークラスを生成する具象ファクトリークラス
│  │      MoveCommandSelectorFactory.cs    [3] 移動時のコマンドセレクタークラスを生成する具象ファクトリークラス
│  │      TownCommandSelectorFactory.cs    [3] 街のコマンドセレクタークラスを生成する具象ファクトリークラス
│  │                                       
│  └─item                                 
│          CommandSelector.cs              [3] 行動コマンドを選択するインターフェース
│          BattleCommandSelector.cs        [3] 戦闘シーンにおける行動を選択するクラス
│          MoveCommandSelector.cs          [3] 移動時における行動を選択するクラス
│          TownCommandSelector.cs          [3] 街シーンにおける行動を選択するクラス
│
├─strategy                                 
│      IStrategy.cs                        [5] モンスターの戦略を定義するインターフェース
│      NormalStrategy.cs                   [5] 通常攻撃の戦略クラス
│      SmashAttackAndHealStrategy.cs       [5] スマッシュ攻撃と回復を織り交ぜた行動を選択する戦略クラス
│      SmashAttackStrategy.cs              [5] スマッシュ攻撃を織り交ぜた行動を選択する戦略クラス
│
├─util                                     
│      CommandHandler.cs                   コマンド選択をハンドリングするクラス（このゲームの肝★）
│      JsonHandler.cs                      Json読書きをハンドリングするクラス
│      LogHandler.cs                       [1] ログ出力をハンドリングするクラス
│      Utility.cs                          ユーティリティクラス
│
└─zz
    └─ConsoleQuest                         各種定義ファイル「C:\temp\配下に格納」
            player.json                    プレイヤー情報が定義ファイル (ゲーム進行により更新されるセーブファイル)
            player.json.init               初期状態のプレイヤーファイル
            level.json                     レベル毎のステータスデータ
            monster.json                   モンスター情報を定義したマスタデータ

*/