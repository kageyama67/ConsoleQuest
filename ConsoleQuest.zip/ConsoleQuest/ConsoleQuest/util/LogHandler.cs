﻿using ConsoleQuest.common;
using NLog;
using NLog.Config;
using NLog.Targets;

namespace ConsoleQuest.util
{
    /**
     * <summary>
     * ロガークラス（シングルトンクラス：NLogを使用）
     * </summary>
     */
    public class LogHandler
    {
        private static Logger logger;

        /**
         * <summary>
         * 静的コンストラクタ(クラス生成時初回のみ実行される)
         * </summary>
         */
        static LogHandler()
        {
            // LoggingConfigurationを生成 
            var config = new LoggingConfiguration();

            // FileTargetを生成し LoggingConfigurationに設定 
            var fileTarget = new FileTarget();
            config.AddTarget("file", fileTarget);

            // fileTargetのプロパティを設定
            fileTarget.Name = "f";
            fileTarget.FileName = Constants.LogFilePath + "${shortdate}.log";
            fileTarget.Layout = "${longdate} [${uppercase:${level}}] ${message}";

            // LoggingRuleを定義
            var rule1 = new LoggingRule("*", LogLevel.Debug, fileTarget);
            config.LoggingRules.Add(rule1);

            // 設定を有効化
            LogManager.Configuration = config;
            logger = LogManager.GetCurrentClassLogger();
        }

        /**
         * <summary>
         * ロガーインスタンスを返却
         * </summary>
         */
        public static Logger Log()
        {
            return logger;
        }
    }
}