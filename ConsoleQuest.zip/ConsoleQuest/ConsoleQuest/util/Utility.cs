﻿using System;
using System.Collections.Generic;
using System.Threading;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.common;
using ConsoleQuest.entity;

namespace ConsoleQuest.util
{
	/**
	 * ユーティリティクラスです。
	 *
	 */
	public class Utility
	{

        /**
         * <summary>
		 * 指定ミリ秒間スリープさせます。
         * </summary>
		 *
		 */
        public static void Sleep(int sleepTimeMS)
        {
			Thread.Sleep(sleepTimeMS);
		}

        /**
         * <summary>
		 * コンソールをクリアします。
         * </summary>
		 *
		 */
        public static void ConsoleClear()
        {
			Console.Clear();
        }

        /**
         * <summary>
		 * Jsonから読み込んだプレイヤー情報を返却します。
         * </summary>
		 *
		 */
        public static PlayerEntity GetPlayerInfo()
		{
			return JsonHandler.FromJson<PlayerEntity>(Constants.JsoFilePathPlayer);
		}

        /**
         * <summary>
         * 初期情報表示
         * </summary>
         */
        public static void DispInitInfo()
        {
            var player = GetPlayerInfo();
            ConsoleClear();
            Console.WriteLine(CommandHandler.GetCommandByKey(CommandTypeEnum.Area, player.area).GetCommandValue1() + "周辺");
            Console.WriteLine("");
        }

        /**
         * <summary>
         * パラメータ情報表示
         * </summary>
         */
        public static void DispParamInfo()
        {
            var player = GetPlayerInfo();
            ConsoleClear();
            Console.WriteLine(player.name);
            Console.WriteLine(" Level : " + player.level);
            Console.WriteLine(" MaxHp : " + player.maxhp);
            Console.WriteLine("    Hp : " + player.hp);
            Console.WriteLine(" MaxMp : " + player.maxmp);
            Console.WriteLine("    Mp : " + player.mp);
            Console.WriteLine("    Ap : " + player.ap);
            Console.WriteLine("    Pp : " + player.pp);
            Console.WriteLine("    Sp : " + player.sp);
            Console.WriteLine("  Gold : " + player.gold);
            Console.WriteLine("   Exp : " + player.exp);
            Console.WriteLine(" Skill :");
            if (player.skills != null)
            {
                player.skills.ForEach(e =>
                    Console.WriteLine("         " + CommandHandler.GetCommandByKey(CommandTypeEnum.Skill, e.skill).GetCommandValue1()));
            }
            else
            {
                Console.WriteLine("         なし");
            }
            Console.WriteLine("");
            Console.WriteLine("Press Any Key.");
            Console.ReadKey();
        }

        /**
         * <summary>
         * ExitParamコマンドリストを返却
         * </summary>
         */
        public static List<string> GetExitParamList()
        {
            var CommandList = new List<string>();
            CommandList.Add(CommandEnum.Param.GetCommandKey());
            CommandList.Add(CommandEnum.Exit.GetCommandKey());
            return CommandList;
        }

        /**
         * <summary>
         * ExitParamコマンドリストを返却
         * </summary>
         */
        public static List<string> GetExitList()
        {
            var CommandList = new List<string>();
            CommandList.Add(CommandEnum.Exit.GetCommandKey());
            return CommandList;
        }

    }
}
