﻿using ConsoleQuest.common.enumerated;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static ConsoleQuest.common.Messages;
using static ConsoleQuest.common.Constants;

namespace ConsoleQuest.util
{
    /**
     * <summary>
     * コマンド入力をハンドリングするクラス
     * </summary>
     */
    public class CommandHandler
    {

        // コマンド
        private const bool FOR_SHOP = true;

        /**
         * <summary>
         * ★選択肢のコマンドと一致する有効な入力コマンドを返却します
         * 　コマンドの選択肢：
         * 　　指定されたコマンドタイプに紐づくコマンドと
         * 　　指定されたコマンドリストを追加したコマンド群
         * </summary>
         * 
         * <param name="commandType">コマンド種別</param>
         * <param name="addList">追加用コマンド</param>
         * <returns>入力された有効なコマンド</returns>
         */
        public static CommandEnum GetInputCommand(CommandTypeEnum commandType, List<string> addList)
        {
            return GetCommand(commandType, null, null, addList);
        }
        /**
         * <summary>
         * 選択肢のコマンドと一致する有効な入力コマンドを返却します
         * 　選択肢：
         * 　　★の選択肢とフィルターコマンドリストの内容が一致したコマンド群
         * </summary>
         * 
         * <param name="commandType">コマンド種別</param>
         * <param name="filterList">フィルターコマンドリスト</param>
         * <param name="addList">追加用コマンド</param>
         * <returns>入力された有効なコマンド</returns>
         */
        public static CommandEnum GetFilterdCommand(CommandTypeEnum commandType, List<string> filterList, List<string> addList)
        {
            return GetCommand(commandType, filterList, null, addList);
        }
        /**
         * <summary>
         * 選択肢のコマンドと一致する有効な入力コマンドを返却します
         * 　選択肢：
         * 　　★の選択肢から除外コマンドリストの内容を除いたコマンド群
         * </summary>
         * 
         * <param name="commandType">コマンド種別</param>
         * <param name="filterList">除外用コマンド</param>
         * <param name="addList">追加用コマンド</param>
         * <returns>入力された有効なコマンド</returns>
         */
        public static CommandEnum GetOmittedCommand(CommandTypeEnum commandType, List<string> omittList, List<string> addList)
        {
            return GetCommand(commandType, null, omittList, addList);
        }

        /**
         * <summary>
         * 条件に合致するコマンドから有効なコマンドを返却する
         * </summary>
         * 
         */
        private static CommandEnum GetCommand(CommandTypeEnum commandType, List<string> filterList, List<string> omittList, List<string> addList)
        {
            while (true)
            {
                var commandList = GetCommandListByType(commandType, filterList, omittList, addList, null);
                DispCommandList(commandList, false);
                var inputCommand = Console.ReadLine();
                var command = ApplyForInputCommand(commandList, inputCommand);
                if (command.Count == 0)
                {
                    // 適用されたコマンドがなければコマンドの入力誤りとしてエラー
                    Console.WriteLine("");
                    Console.WriteLine("Command Error!");
                    continue;
                }
                LogHandler.Log().Info(GetMessage(CMDG0003I, command.First().GetCommandKey()));
                // 入力Commandの返却
                return command.First();
            }
        }

        /**
         * <summary>
         * 指定されたキーなコマンドenumを返却する
         * </summary>
         * <param name="commandType">コマンド種別</param>
         * <param name="key">コマンドキー</param>
         * <returns>指定されたキーに対応するCommandEnum</returns>
         */
        public static CommandEnum GetCommandByKey(CommandTypeEnum commandType, string key)
        {
            while (true)
            {
                var commandList = GetCommandListByType(commandType, null, null, null, null);
                var command = ApplyForInputCommand(commandList, key);
                // 対応するキーの返却
                return command == null ? CommandEnum.Exit : command.First();
            }
        }

        /**
         * <summary>
         * 種別で絞り込んだコマンドリストを返却
         * </summary>
         */
        private static List<CommandEnum> GetCommandListByType(
            CommandTypeEnum commandType, List<string> filterList, List<string> omittList, List<string> addList, string area)
        {
            return Enum.GetValues(typeof(CommandEnum))
                .Cast<CommandEnum>().ToList()
                .Where(e => {
                    return (e.GetCommandType() == commandType
                           && AreaFilter(e, area)
                           && ListChecker(e, filterList, omittList))
                           || AddOtherTypeCommand(e, addList);
                }).ToList();
        }

        /**
         * <summary>
         * フィルタ対象/除外対象判定
         * </summary>
         * 
         * <param name="comand">判定対象のコマンド</param>
         * <param name="comand">フィルタしたいコマンドリスト</param>
         * <param name="comand">除外したいコマンドリスト</param>
         */
        private static bool ListChecker(CommandEnum comand, List<string> filterList, List<string> omittList)
        {
            if (filterList == null && omittList == null)
            {
                return true;
            }
            if (filterList != null && filterList.Contains(comand.GetCommandKey()))
            {
                return true;
            }
            if (omittList != null && !omittList.Contains(comand.GetCommandKey()))
            {
                return true;
            }
            return false;
        }

        /**
         * <summary>
         * 他のタイプのコマンドリスト出力
         * </summary>
         */
        private static bool AddOtherTypeCommand(CommandEnum comand, List<string> addList)
        {
            if (addList == null)
            {
                return false;
            } else if (addList.Contains(comand.GetCommandKey()))
            {
                return true;
            }
            return false;
        }

        /**
         * <summary>
         * エリアによるコマンドの絞り込み
         * </summary>
         */
        private static bool AreaFilter(CommandEnum comand, string area)
        {
            if (area == null)
            {
                return true;
            }
            else if (comand.GetCommandValue2().Contains(area))
            {
                return true;
            }
            return false;
        }

        /**
         * <summary>
         * 入力コマンドをCommandEnumのコマンド名と比較して一致したコマンドをリストとして(最大1件)返却する
         * </summary>
         */
        private static List<CommandEnum> ApplyForInputCommand(List<CommandEnum> AppStateList, string str)
        {
            // 入力Commandチェック
            return AppStateList
                // 入力したコマンドで絞り込み
                .Where(
                    e => e.GetCommandKey() == str).ToList();
        }

        /**
         * <summary>
         * 入力された有効なItemコマンドを返却する
         * 　標準入力待ちが発生する為、テスト不可。
         * </summary>
         * <param name="commandType">コマンド種別</param>
         * <param name="addList">追加コマンド</param>
         * <param name="area">エリア</param>
         * <param name="unnesessaryExit">Exitコマンド不要フラグ(trueの場合)</param>
         * <returns>入力された有効なCommandEnum</returns>
         */
        public static CommandEnum InputCommandForItem(CommandTypeEnum commandType, List<string> addList, string area)
        {
            while (true)
            {
                var commandList = GetCommandListByType(commandType, null, null, addList, area);
                DispCommandList(commandList, FOR_SHOP);
                var inputCommand = Console.ReadLine();
                var command = ApplyForInputCommand(commandList, inputCommand);
                if (command.Count == 0)
                {
                    // 適用されたコマンドがなければコマンドの入力誤りとしてエラー
                    Console.WriteLine("Command Error!");
                    continue;
                }
                // 入力Commandの返却
                return command.First();
            }
        }

        /**
         * <summary>
         * コマンドリストの表示
         * </summary>
         */
        private static void DispCommandList(List<CommandEnum> AppStateList, bool ForShop)
        {
            Console.WriteLine("Input Command!");
            // Commandリスト出力
            AppStateList
                // 入力コマンドを表示
                .ForEach(
                    o => SetDisplay(o, ForShop)
                );
        }

        /**
         * <summary>
         * コマンドリストの整形
         * </summary>
         */
        private static void SetDisplay(CommandEnum commandEnum, bool ForShop)
        {
            Encoding utf8Enc = Encoding.GetEncoding("UTF-8");
            Console.Write(" : " + commandEnum.GetCommandKey());
            if (!ForShop)
            {
                // 通常コマンド
                Console.WriteLine(string.Concat(Enumerable.Repeat(" ", CommandWidthFromKeyToDescription - utf8Enc.GetByteCount(commandEnum.GetCommandKey()))) +
                    commandEnum.GetCommandValue1());
                return;
            }
            // ショップ用コマンド
            Console.Write(
                string.Concat(Enumerable.Repeat(" ", CommandWidthFromKeyToDescription - utf8Enc.GetByteCount(commandEnum.GetCommandKey()))) +
                commandEnum.GetCommandValue1()
            );
            Console.WriteLine(
                string.Concat(Enumerable.Repeat(" ", CommandWidthFromDescriptionToPrice - (((utf8Enc.GetByteCount(commandEnum.GetCommandValue1()) / 3) * 2) + 
                    utf8Enc.GetByteCount(commandEnum.GetCommandValue3()) + 1))) +
                    commandEnum.GetCommandValue3() + (string.IsNullOrEmpty(commandEnum.GetCommandValue3()) ? "" : "G")
            );
        }
    }
}
