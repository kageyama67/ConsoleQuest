﻿using System.Text.Json;
using System.Text.Encodings.Web;
using System.Text.Unicode;
using System.IO;

namespace ConsoleQuest.util
{
    /**
     * Jsonの入出力を行うクラス
     */
    public class JsonHandler
    {
        /**
         * <summary>
         * jsonファイルを読み込み、指定型のオブジェクトに変換する
         * </summary>
         * <param name="path">Jsonファイルのパス</param>
         * <returns>Jsonの内容を保持したEntityオブジェクト</returns>
         */
        public static E FromJson<E>(string path)
        {
            return JsonSerializer.Deserialize<E>(File.ReadAllText(path));
        }
        /**
         * <summary>
         * 指定型のオブジェクトを読み込みjsonファイルに保存する
         * </summary>
         * <param name="path">Jsonファイルのパス</param>
         * <param name="path">指定型のオブジェクト</param>
         * <returns>Jsonの内容を保持したEntityオブジェクト</returns>
         */
        public static void ToJson<E>(string path, E entity)
        {
            // Jsonファイル保存時のオプション
            //  1: WriteIndented = true                         (Jsonをインデント付きに整形して保存する)
            //  2: JavaScriptEncoder.Create(UnicodeRanges.All)  (マルチバイトに対応)
            var options = new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.All)
            };
            File.WriteAllText(path, JsonSerializer.Serialize(entity, options));
        }

    }
}