﻿using ConsoleQuest.common.enumerated;
using ConsoleQuest.entity;

namespace ConsoleQuest.strategy
{
	/**
	 * モンスターの戦略を表現する共通インターフェースです。
	 *
	 */
	public interface IStrategy
	{
		/**
		 * <summary>
		 * 戦略によって決定されたバトルアクションを返却します。
		 * </summary>
		 * 
		 * <param name="monsterAction">モンスターの状態を保持するクラス</param>
		 * <param name="monsterAction">プレイヤーの状態を保持するクラス</param>
		 * <returns>決定されたアクション</returns>
		 */
		public abstract BattleActionEnum SelectAction(MonsterEntity monster, PlayerEntity player);
	}
}
