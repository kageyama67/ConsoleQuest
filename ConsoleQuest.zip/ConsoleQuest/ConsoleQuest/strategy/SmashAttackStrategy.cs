﻿using System;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.entity;

namespace ConsoleQuest.strategy
{
	/**
	 * スマッシュアタック(1/2)の戦略クラスです。
	 *
	 */
	public class SmashAttackStrategy : IStrategy
	{

		/**
		 * <summary>
		 * ノーマルアタックとスマッシュアタックを半々の確率で返却するメソッドです。
		 * </summary>
		 *
		 */
		public BattleActionEnum SelectAction(MonsterEntity monster, PlayerEntity player)
		{
			var rand = new Random();
			return ((rand.Next(2))) == 1 ? BattleActionEnum.SmashAttack : BattleActionEnum.NormalAttack;
		}
	}
}
