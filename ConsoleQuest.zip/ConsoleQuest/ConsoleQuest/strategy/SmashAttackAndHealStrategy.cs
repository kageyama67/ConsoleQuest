﻿using System;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.entity;

namespace ConsoleQuest.strategy
{

	/**
	 * <summary>
	 * スマッシュアタック or ホイミを選択する戦略クラスです。
	 * </summary>
	 *
	 */
	public class SmashAttackAndHealStrategy : IStrategy
	{

		/**
		 * <summary>
		 * 通常攻撃、スマッシュアタック、ホイミのいずれかのアクションを返却します。
		 * </summary>
		 * 
		 */

		public BattleActionEnum SelectAction(MonsterEntity monster, PlayerEntity player)
		{
			var rand = new Random();

            switch (rand.Next(3))
			{
				case 0:
					return BattleActionEnum.NormalAttack;
				case 1:
					return BattleActionEnum.SmashAttack;
				case 2:
					if (monster.maxhp == monster.hp)
						return BattleActionEnum.NormalAttack;
					if (BattleActionEnum.Hoimi.GetBattleActionMp() <= monster.mp)
						return BattleActionEnum.Hoimi;
					return BattleActionEnum.NormalAttack;
				default:
					return BattleActionEnum.NormalAttack;
			}
		}

	}

}
