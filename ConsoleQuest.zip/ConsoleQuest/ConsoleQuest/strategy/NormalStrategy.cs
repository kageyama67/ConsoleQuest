﻿using ConsoleQuest.common.enumerated;
using ConsoleQuest.entity;

namespace ConsoleQuest.strategy
{
    /**
	 * 通常攻撃の戦略クラスです。
	 *
	 */
    public class NormalStrategy : IStrategy
    {

        /**
         * <summary>
         * 常に通常攻撃を返却します。
         * </summary>
         *
         */
        public BattleActionEnum SelectAction(MonsterEntity monster, PlayerEntity player)
        {
            return BattleActionEnum.NormalAttack;
        }
    }
}
