﻿namespace ConsoleQuest
{
	public class BattleDO
	{
		public int attack { get; set; }
		public int protectBreakAttack { get; set; }
		public int protect { get; set; }
		public int guard { get; set; }
	}
}
