﻿using System;
using ConsoleQuest.common.enumerated;
using ConsoleQuest.util;
using ConsoleQuest.scene.factory;
using static ConsoleQuest.common.enumerated.CommandEnum;
using static ConsoleQuest.common.Messages;

namespace ConsoleQuest
{
    /**
     * <summary>
     * エントリポイント
     * NugetからNlogのインストールが必要
     * </summary>
     */
    class Program
    {
        /**
         * <summary>
         * ゲームスタート
         * </summary>
         */
        public static void Main(string[] args)
        {
            try
            {
                LogHandler.Log().Info(CMDG0001I);
                while (true)
                {
                    Utility.DispInitInfo();
                    var command = CommandHandler.GetInputCommand(CommandTypeEnum.Field, Utility.GetExitParamList());
                    CommandSelectorFactory factory = null;
                    switch (command)
                    {
                        case Battle:
                            // バトルする
                            factory = new BattleCommandSelectorFactory();
                            break;
                        case Town:
                            // 街に行く
                            factory = new TownCommandSelectorFactory();
                            break;
                        case Move:
                            // 移動する
                            factory = new MoveCommandSelectorFactory();
                            break;
                        case Param:
                            // パラメータ表示
                            Utility.DispParamInfo();
                            break;
                        case Exit:
                            // ゲーム終了
                            LogHandler.Log().Info(CMDG0002I);
                            return;
                        default:
                            // 未実装コマンド
                            Console.WriteLine(CMDG0004I);
                            Utility.Sleep(800);
                            break;
                    }
                    if (factory == null) continue;
                    var action = factory.Create();
                    action.Start();
                }

            } catch (Exception ex)
            {
                // エラーハンドリング（長手抜き）
                Console.WriteLine(CMDG0001E,   ex.Message);
                LogHandler.Log().Info(CMDG0099E, "ex.Message     : ", ex.Message);
                LogHandler.Log().Info(CMDG0099E, "ex.Source      : ", ex.Source);
                LogHandler.Log().Info(CMDG0099E, "ex.StackTrace  : \n", ex.StackTrace);
                LogHandler.Log().Info(CMDG0099E, "ex.TargetSite  : \n", ex.TargetSite);
            }
        }
    }
}
